import json, tempfile, subprocess, sys
from pathlib import Path
root=Path(__file__).parent
with tempfile.TemporaryDirectory() as d:
    out=Path(d)/'out'
    subprocess.run([sys.executable,'starter/python/runner.py','--input','data','--output',str(out)],check=True)
    rooms=sorted(out.iterdir())
    assert len(rooms)==5
    for room in rooms:
        layout=json.loads((room/'layout.json').read_text())
        quote=json.loads((room/'quote.json').read_text())
        assert layout['status'] in {'valid','unsatisfiable','invalid'}
        assert quote['currency']=='INR'
print('SMOKE TEST PASSED')
